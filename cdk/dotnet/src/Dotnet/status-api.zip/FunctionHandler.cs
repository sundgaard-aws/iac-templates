namespace IAC.Demo {
    public class FunctionHandler {
        public void Invoke() {
            
        }
    }   
}